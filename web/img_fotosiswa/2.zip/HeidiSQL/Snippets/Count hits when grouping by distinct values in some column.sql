SELECT t1.row1 r1, COUNT(*) hits
FROM table1 t1
GROUP BY
	r1
